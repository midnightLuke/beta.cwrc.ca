<?php

/**
 * @file
 * The default view to print objects.
 *
 */
?>
<div>
  <div>
    <?php print $islandora_content; ?>
  </div>
  <?php print $metadata; ?>
</div>
