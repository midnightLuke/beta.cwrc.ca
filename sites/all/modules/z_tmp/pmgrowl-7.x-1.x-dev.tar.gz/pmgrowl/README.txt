Installation
------------

1. Download and extract this and privatemsg module into your modules
   directory.
2. Download the Growl plugin from http://stanlemon.net/pages/jgrowl
   and extract it inside of the pmgrowl module directory.
3. Make sure that the jquery.jgrowl.css, and the jquery.jgrowl_minimized.js
   files are both directly inside of the pmgrowl/jgrowl directory.
4. Enable the module.
5. Settings can be found at admin/config/messaging/privatemsg
