<?php
// $Id$
$path = drupal_get_path('module', 'graphmind_service');
include $path . '/node-graphmind.tpl.php';