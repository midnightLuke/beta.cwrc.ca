directory contains:
- amfserver logos
- crossdomain.xml file
  In case you want to connect to the amfserver from a different domain or a subdomain, place the crossdomain.xml file in the site root directory of the drupal installation and configure the uri's from which you want to allow access to the amfserver in the crossdomain.xml file.
- endpoint.txt
  contains the export of a default (testing) endpoint